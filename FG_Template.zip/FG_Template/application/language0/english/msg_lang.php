<?php
$lang['logout'] = "logout";
$lang['error_username_missing'] = 'You must submit a username';
$lang['for_current_user'] = 'For Current Users';
$lang['profile'] = 'Profile';
$lang['upload'] = 'Upload'; 













 ?>
