<?php
$lang['logout'] = "Spanishlogout";
$lang['for_current_user'] = 'Para los usuarios actuales';
$lang['profile'] = 'Perfil';
$lang['upload'] = 'Subir';













 ?>
