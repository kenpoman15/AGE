<?php
$lang['logout'] = "Spanishlogout";
$lang['for_current_user'] = 'Pour les utilisateurs actuels';
$lang['profile'] = 'Perfil';
$lang['upload'] = 'Subir';














 ?>
