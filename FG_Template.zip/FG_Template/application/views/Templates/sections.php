<?php
foreach($sections as $section){
  print_r($section);
}
?>
