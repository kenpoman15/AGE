  <footer>
<center><em>Kevin Medara, AJ Taft, Mitch Hale, John ?, ? &copy;2017</em></center>
  </footer>
